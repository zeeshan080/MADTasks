package com.example.sqllitestudent

class StdModelClass(val id:Int, val name:String, val session:String, val regNumber:String)