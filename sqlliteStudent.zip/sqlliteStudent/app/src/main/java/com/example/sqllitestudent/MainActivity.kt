package com.example.sqllitestudent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.sqliteexampleapp.DatabaseHandler

class MainActivity : AppCompatActivity() {
    lateinit var  stdItemsList: RecyclerView
    lateinit var NoRecordsAvailable: TextView
    lateinit var stdName: EditText
    lateinit var stdSession: EditText
    lateinit var stdReg: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnAdd=findViewById<Button>(R.id.btnAdd)
        val btnSearch = findViewById<Button>(R.id.btnSearch)
        stdName=findViewById(R.id.stdName)
        stdSession=findViewById(R.id.stdSession)
        stdReg = findViewById(R.id.stdReg)

        //click event of search user
        btnSearch.setOnClickListener(){
            val intent = Intent(this,searchStudent::class.java)
            startActivity(intent)
        }
        // Click even of the add button.
        btnAdd.setOnClickListener { view ->

            addRecord()
        }
    }


    //Method for saving the employee records in database
    private fun addRecord() {
        val name = stdName.text.toString()
        val session = stdSession.text.toString()
        val reg = stdReg.text.toString()

        val databaseHandler: DatabaseHandler = DatabaseHandler(this)
        if (name.isNotEmpty() && session.isNotEmpty() && reg.isNotEmpty()) {
            val status =
                databaseHandler.addStudent(StdModelClass(0, name, session, reg))
            if (status > -1) {
                Toast.makeText(applicationContext, "Record saved", Toast.LENGTH_LONG).show()
                stdName.text.clear()
                stdSession.text.clear()
                stdReg.text.clear()
                //setupListofDataIntoRecyclerView()
            }
            else{
                Toast.makeText(
                    applicationContext,
                    "Data not inserted",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(
                applicationContext,
                "Name, Session or Reg no cannot be blank",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}