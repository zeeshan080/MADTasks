package com.example.sqliteexampleapp

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import com.example.sqllitestudent.DBContract.StdEntry.Companion.KEY_SESSION
import com.example.sqllitestudent.DBContract.StdEntry.Companion.KEY_ID
import com.example.sqllitestudent.DBContract.StdEntry.Companion.KEY_NAME
import com.example.sqllitestudent.DBContract.StdEntry.Companion.KEY_REG
import com.example.sqllitestudent.DBContract
import com.example.sqllitestudent.StdModelClass

//creating the database logic, extending the SQLiteOpenHelper base class
class DatabaseHandler(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private val DATABASE_VERSION = 1
        private val DATABASE_NAME = "StudentDatabase"

    }

    override fun onCreate(db: SQLiteDatabase?) {
        //creating table with fields
        val CREATE_CONTACTS_TABLE = ("CREATE TABLE " + DBContract.StdEntry.TABLE_Name + "("
                + DBContract.StdEntry.KEY_ID + " INTEGER PRIMARY KEY," + DBContract.StdEntry.KEY_NAME + " TEXT,"
                + DBContract.StdEntry.KEY_REG + " TEXT," + DBContract.StdEntry.KEY_SESSION + " TEXT" + ")")

        db?.execSQL(CREATE_CONTACTS_TABLE)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS ${DBContract.StdEntry.TABLE_Name}")
        onCreate(db)
    }
    /**
     * Function to insert data
     */
    fun addStudent(std: StdModelClass): Long {
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(DBContract.StdEntry.KEY_NAME, std.name) // StdModelClass Name
        contentValues.put(DBContract.StdEntry.KEY_SESSION, std.session) // StdModelClass Email
        contentValues.put(DBContract.StdEntry.KEY_REG, std.regNumber) // StdModelClass Email

        // Inserting employee details using insert query.
        val success = db.insert(DBContract.StdEntry.TABLE_Name,null , contentValues)
        //2nd argument is String containing nullColumnHack

        return success
        //db.close() // Closing database connection
    }
    //Method to read the records from database in form of ArrayList
    @SuppressLint("Range")
    fun viewStudent(): ArrayList<StdModelClass> {

        val stdList: ArrayList<StdModelClass> = ArrayList<StdModelClass>()

        // Query to select all the records from the table.
        val selectQuery = "SELECT  * FROM ${DBContract.StdEntry.TABLE_Name}"

        val db = this.readableDatabase
        // Cursor is used to read the record one by one. Add them to data model class.
        var cursor: Cursor? = null

        try {
            cursor = db.rawQuery(selectQuery, null)

        } catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }

        var id: Int
        var name: String
        var session: String
        var regno: String

        if (cursor.moveToFirst()) {
            do {
                id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                name = cursor.getString(cursor.getColumnIndex(KEY_NAME))
                session = cursor.getString(cursor.getColumnIndex(KEY_SESSION))
                regno = cursor.getString(cursor.getColumnIndex(KEY_REG))
                val emp = StdModelClass(id = id, name = name, session = session, regNumber = regno)
                stdList.add(emp)

            } while (cursor.moveToNext())
        }
        return stdList
    }

    @SuppressLint("Range")
fun searchStudent(std: StdModelClass): ArrayList<StdModelClass>{
    val stdList: ArrayList<StdModelClass> = ArrayList<StdModelClass>()

    // Query to select all the records from the table.
    val selectQuery = "SELECT  * FROM ${DBContract.StdEntry.TABLE_Name} WHERE ${DBContract.StdEntry.KEY_REG} == ${std.regNumber}"

    val db = this.readableDatabase
    // Cursor is used to read the record one by one. Add them to data model class.
    var cursor: Cursor? = null

    try {
        cursor = db.rawQuery(selectQuery, null)

    } catch (e: SQLiteException) {
        db.execSQL(selectQuery)
        return ArrayList()
    }

    var id: Int
    var name: String
    var session: String
    var regno: String

    if (cursor.moveToFirst()) {
        do {
            id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
            name = cursor.getString(cursor.getColumnIndex(KEY_NAME))
            session = cursor.getString(cursor.getColumnIndex(KEY_SESSION))
            regno = cursor.getString(cursor.getColumnIndex(KEY_REG))
            val emp = StdModelClass(id = id, name = name, session = session, regNumber = regno)
            stdList.add(emp)

        } while (cursor.moveToNext())
    }
    return stdList
}
   
}