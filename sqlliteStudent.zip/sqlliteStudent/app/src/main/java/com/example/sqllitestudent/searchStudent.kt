package com.example.sqllitestudent

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sqliteexampleapp.DatabaseHandler

class searchStudent: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.searchstudent)
        val btnBack = findViewById<Button>(R.id.btnBack)
        val btnSearch = findViewById<Button>(R.id.btnSearch)

        btnSearch.setOnClickListener() {
            searchStd()
        }
        btnBack.setOnClickListener() {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }


    private fun searchStd() {
        val stdSearchField = findViewById<EditText>(R.id.stdSearchField)
        val stdSearch = stdSearchField.text.toString()
        val databaseHandler: DatabaseHandler = DatabaseHandler(this)
        if (stdSearch.isNotEmpty()) {
            val status: ArrayList<StdModelClass> =
                databaseHandler.searchStudent(StdModelClass(0, "", "", stdSearch))
             val viewSearch: RecyclerView
             viewSearch = findViewById(R.id.viewSearch)
            // Set the LayoutManager that this RecyclerView will use.
            viewSearch.layoutManager = LinearLayoutManager(this)
            // Adapter class is initialized and list is passed in the param.
            //val itemAdapter = ItemAdapter(this, status)
            // adapter instance is set to the recyclerview to inflate the items.
            //viewSearch.adapter = itemAdapter
        }
    }
}